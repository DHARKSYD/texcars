import aeriel_blue_car from './areal_blue_car.jpg'
import gwagon_grey_car from './gwagon_black_car.jpg'
import hero_car from 'from./hero_car.jpg' 
import lambourghini_yellow_car from 'from./lambourghini_yellow_car.jpg' 
import mercedes_race_car from 'from./mercedes_race_car.jpg' 
import shadowed_red_car from 'from./shadowed_red_car.jpg' 
import sports_blue_car from 'from./sports_blue_car.jpg'

export const ASSETS = {

aeriel_blue_car,
gwagon_grey_car,
hero_car,
lambourghini_yellow_car,
mercedes_race_car,
shadowed_red_car,
sports_blue_car,
}