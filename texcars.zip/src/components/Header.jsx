import React from 'react'
import { AiOutlineCar } from 'react-icons/ai'
import { Link } from 'react-router-dom'
import { PiShoppingCartLight } from 'react-icons/pi'
import { RiMenu3Fill } from 'react-icons/ri'

export default function Header() {

  const navLinks = [
    { id: "1", name: 'Home', path: '/' },
    { id: "2", name: 'About', path: '/about' },
    { id: "3", name: 'Shop', path: '/shop' },
    { id: "4", name: 'Contact', path: '/contact' },
  ]

  return (
    <header className='bg-[#161616] p-4'>

        <div className="container mx-auto relative flex justify-between gap-4">
            <Link to="/" className='h-8 w-10 flex items-center gap-2'>
                <AiOutlineCar className='text-white text-lg md:text-2xl flex-shrink-0' />
                <span className='text-[#e11836] text-lg md:text-2xl font-bold'>TexCars</span>
            </Link>


            <nav className='flex-1 relative flex justify-center gap-2 '>
                {navLinks.map(link => (
                  <Link key={link.id} to={link.path} className='text-white hover:bg-[#e11836] px-2 py-2 rounded-md text-md font-medium'>
                    {link.name}
                  </Link>
                ))}
            </nav>
                
            <div className='flex gap-2 w-max'>
              <Link to="/cart" className='relative p-2 text-base md:text-lg text-white hover:bg-[#e11836] px-2 py-2 rounded-md'>
                <PiShoppingCartLight />
                </Link>
              <div className='relative p-2 text-base md:text-lg text-white hover:bg-[#e11836] px-2 py-2 rounded-md'>
                <RiMenu3Fill />
              </div>
              </div>
        </div>

    </header>
  )
}