import React from 'react'

export default function Footer() {
  return (
    <footer className="w-full bg-[#161616] py-4 mt-auto">
      <div className="container mx-auto flex justify-center items-center text-[#e11836] text-sm">
        © Orendu's Brain Activity {new Date().getFullYear()}. All rights reserved.
      </div>
    </footer>
  )
}
