import React from 'react'

export default function Home() {
  return (
    <main className="relative">
      <section className="relative bg-gradient-to-tr from-[#161616] via-slate-600 to-[#161616] py-16 px-4 sm:px-6 lg:px-8"></section>
    <div>
    <img src="assets" alt="" className='h-40.object--cover.object-center' />
    </div>
    </main>
  )
}
